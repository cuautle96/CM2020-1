//
//  ViewController.swift
//  Primer-Examen
//
//  Created by 2020-1 on 9/20/19.
//  Copyright © 2019 Mike. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var buttonEnviarTrivia: UIButton!
    @IBOutlet var switch1: UISwitch!
    @IBOutlet var switch2: UISwitch!
    @IBOutlet var switch3: UISwitch!
    @IBOutlet var switch4: UISwitch!
    @IBOutlet var switch5: UISwitch!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var slider1: UISlider!
    @IBOutlet weak var slider12: UISlider!
    @IBOutlet weak var label12: UILabel!
    
    @IBOutlet weak var codigoPromo: UITextField!
    @IBOutlet weak var total: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonEnviar(_ sender: Any){
        if switch1.isOn{
            performSegue(withIdentifier: "goFalla", sender: nil)
        }else{
            if switch2.isOn{
                if switch3.isOn{
                    if switch4.isOn{
                        performSegue(withIdentifier: "goFalla", sender: nil)
                    }else{
                        if switch5.isOn{
                            performSegue(withIdentifier: "goBien", sender: nil)
                        }else{
                            performSegue(withIdentifier: "goFalla", sender: nil)
                        }
                    }
                }else{
                    performSegue(withIdentifier: "goFalla", sender: nil)
                }
            }else{
                performSegue(withIdentifier: "goFalla", sender: nil)
            }
            
        }
    }
    
    @IBAction func sliderCant(_ sender: UISlider) {
        var number = 0
        number = Int(sender.value)
        if number > 10{
            number = 0
        }
        label12.text = String(number)
        total_compra()
    }
    
    @IBAction func slider2Cant(_ sender: UISlider) {
        var number = 0
        number = Int(sender.value)
        if number > 10{
            number = 0
        }
        label1.text = String(number)
        total_compra()
    }
    
    @IBAction func total_compra() {
        let slider_1_value = Int(slider1.value)
        let slider_2_value = Int(slider12.value)
        
        //var slider_1_value = slider_1_value.rounded()
        
        var promo:String = "hola"
        promo = codigoPromo.text?.uppercased() ?? "hola"
        print(promo)
        if promo == "MORAT96"{
            let compra:Double = Double(slider_1_value * 150 + slider_2_value * 150)
            let precio_promo = compra * 0.75
            total.text = "$" + String(precio_promo)
        }else{
            let compra = slider_1_value * 150 + slider_2_value * 150
            total.text = "$" + String(compra)
        }
    }
}

